---
license: mit
language:
- it
task_categories:
- question-answering
- text-generation
tags:
- benchmark
- reasoning
- deterministic
- algorithms
- math
- data-structures
size_categories:
- 100K<n<1M
pretty_name: CoreLang5 Benchmark
---

# CoreLang5 Benchmark

**117,000 deterministic computational reasoning problems across 11 domains.**

Each problem has an exact, verifiable answer — no ambiguity, no subjectivity. Designed for evaluating LLM reasoning on concrete computational tasks.

## Dataset Structure

| File | Domain | Problems |
|------|--------|----------|
| `block01_logic_and_controlflow.jsonl` | Logic & Control Flow | 10,000 |
| `block02_math_and_algebra.jsonl` | Math & Algebra | 10,000 |
| `block03_data_structures.jsonl` | Data Structures | 12,000 |
| `block04_algorithms.jsonl` | Algorithms | 15,000 |
| `block05_io_and_serialization.jsonl` | I/O & Serialization | 10,000 |
| `block06_concurrency_and_async.jsonl` | Concurrency & Async | 10,000 |
| `block07_interop_and_ffi.jsonl` | Interop & FFI | 10,000 |
| `block08_systems_and_networking.jsonl` | Systems & Networking | 10,000 |
| `block09_optimization_and_profiling.jsonl` | Optimization & Profiling | 10,000 |
| `block10_domain_adapters.jsonl` | Domain Adapters | 10,000 |
| `block11_crypto_interop.jsonl` | Crypto & Interop | 10,000 |
| **Total** | | **117,000** |

## Record Format

Each line is a JSON object:

```json
{
  "id": "CL5-1-000001",
  "version": "5.0",
  "block": 1,
  "category": "Logic_and_ControlFlow",
  "title": "FOR iterations_leq start=-50 end=-50 step=1",
  "prompt": "For con condizione i <= end: i parte da -50, step 1, end -50. Quante iterazioni?",
  "solution": "1",
  "difficulty": 2,
  "topics": ["for_loop", "inclusive", "For <= iterations"],
  "answer_type": "free_text",
  "lang": "it",
  "estimated_time_min": 2,
  "tags": ["logic_and_controlflow", "for_<=_iterations"],
  "hash": "c5dfc01a506b1a498a0de6264784c8a59d0c0595ce00ec2dbcac7f8dfa678ff1",
  "token": "CL5_FOR_ITERATIONS_LEQ_START_50_END_50_STEP1_0001"
}
```

## Key Properties

- **Deterministic answers** — every solution is a number or short string, verifiable programmatically
- **Difficulty levels** — 1 (trivial) to 7 (very hard), graduated within each block
- **Unique tokens** — each problem has a unique identifier for deduplication
- **SHA-256 hash** — integrity verification per problem
- **Italian prompts** — problems are written in Italian (v5.0)

## Intended Use

- Evaluating LLM reasoning on deterministic computational tasks
- Benchmarking models by domain (algorithms, data structures, networking, etc.)
- Training data for step-by-step reasoning (when paired with a solver)
- Fine-tuning for technical/mathematical problem solving (with caution: avoid leakage)

## Example Problems

**Logic (Block 1):**
> "For con condizione i <= end: i parte da -50, step 1, end -50. Quante iterazioni?" → `1`

**Math (Block 2):**
> "Calcola 1+2+...+n per n=1297." → `841753`

**Data Structures (Block 3):**
> "Fenwick tree: parent(x)=x−LSB(x). Calcola parent(166)." → `164`

**Networking (Block 8):**
> "Credit-based: init=65535, sent=2534, ack=1326. Finestra disponibile?" → `64327`

## License

MIT

## Citation

If you use this dataset, please cite:

```bibtex
@dataset{corelang5_benchmark,
  title={CoreLang5 Benchmark: 117k Deterministic Computational Reasoning Problems},
  author={Pietro Risi},
  year={2025},
  url={https://huggingface.co/datasets/pietrorisipr-2025/corelang5-benchmark}
}
```
